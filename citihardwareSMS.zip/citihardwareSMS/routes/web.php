<?php

use App\Models\Store;
use App\Models\Employee;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\empController;
use App\Http\Controllers\userController;
use App\Http\Controllers\storeController;
use App\Http\Controllers\storeEmpController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    //$store = [];
    
   // if (auth()->check()){
     //   $store = auth()->user()->createnewStore()->latest()->get();}
    //$store = Store::where('user_id',->auth()->id()->get());
    $store = Store::all();
    $employee = Employee::all();
    return view('home', ['stores' =>$store]);
});


Route::get('/edit-emp', function () {
  $store = Store::all();
  return view('edit-emp', ['stores' =>$store]);
});

Route::get ('/register',[userController::class, 'registerPage']);
Route::put ('/register', [userController::class, 'register']);
Route::post ('/login', [userController::class, 'login']);
Route::post ('/logout',[userController::class, 'logout']);

//store routes
Route::post('/store', [storeController::class, 'createStore']);
Route::get('/edit-store/{store}', [storeController::class, 'editStore']);
Route::put('/edit-store/{store}', [storeController::class, 'updateStore']);
Route::delete('/delete-store/{store}', [storeController::class, 'deleteStore']);


//employee routes
Route::post('/employee',[empController::class,'createEmployee']);
Route::get('/emp-info',[empController::class,'employeeNav','employeeShow']);

Route::get('/edit-emp/{employee}', [empController::class, 'editEmp']);
Route::put('/edit-emp/{employee}', [empController::class, 'updateEmployee']);
Route::delete('/delete-emp/{employee}', [empController::class, 'deleteEmp']);

Route::get('/view-emp/{store}', [storeController::class, 'showEmployees']);
Route::get('/edit-emp/{employee}', [empController::class, 'populate']);