<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body style="background-color:#D8D9DA">
    
    <br>
        <br>
    <div class="container">
       <form class="row g-4" action="/edit-emp/<?php echo e($employee->id); ?>" method="POST">
        <?php echo csrf_field(); ?> 
        <?php echo method_field('PUT'); ?>
        
            <h1 class="h3 mb-3 font-weight-normal">Edit Employee Information</h1>
            <div class="col-md-6">  
                <label for="inputemp-name" class="form-label">Fullname</label>    
                <input name = "emp_name" id="inputemp-name" class="form-control" type="text" value="<?php echo e($employee->emp_name); ?>">
            </div>
            <div class="col-md-6">
                <label for="inputPosition" class="form-label">Position</label>
                <select name="position" id="inputPosition" class="form-select">
                    <option value="cashier">Cashier</option>
                    <option value="manager">Manager</option>
                    <option value="salesperson">Salesperson</option>
                </select>
            </div>
            <div class="col-md-6">  
                <label for="inputPhone" class="form-label">Contact Number</label>
                <input name="phone_number" id="inputPhone" class="form-control" type="number" value="<?php echo e($employee->phone_number); ?>">
            </div>
            <div class="col-md-6">
                <label for="inputEmail" class="form-label">Email</label>
                <input name="email" id="inputEmail" class="form-control" type="email" value="<?php echo e($employee->email); ?>">
            </div>
            <div class="col-md-6">
                <label for="inputAddress" class="form-label">Address</label>
                <input name="address" id="inputAddress" class="form-control" type="text" value="<?php echo e($employee->address); ?>">
            </div>
            <div class="col-md-6">
                <label for="inputStore" class="form-label">Position</label>
                    <select name="assign_store" id="inputStore" class="form-select">
                        <option selected disabled><?php echo e($employee->assign_store); ?></option>
                        <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($store->storeName); ?>"><?php echo e($store->storeName); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
            </div>
            <div class="col-12 d-md-flex justify-content-md-end">
                <button class="btn btn-outline-primary">Save Changes</button>
            </div>
        </form>
    </div>
</body>
</html>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\john paul\Desktop\laravel-project\citihardwareSMS\resources\views/edit-emp.blade.php ENDPATH**/ ?>