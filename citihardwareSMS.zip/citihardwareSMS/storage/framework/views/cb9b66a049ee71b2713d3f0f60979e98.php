<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body style="background-color:#D8D9DA">
    

    <div class="container">
        <?php 
        $employeeCount = count($employees); // Get the total number of employees
        ?>
        <div>
            <h1 class="h3 mb-3 font-weight-normal">Associated Employees</h1>
        </div>
        
        <p>Total Employees: <?php echo e($employeeCount); ?></p>
        <div class="row">
            <div class="col-md-12">
                <table class="table table-responsive">
                <thead class="table-dark">
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Email</th>

                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($employee->id); ?></th>
                    <td><?php echo e($employee->emp_name); ?></td>
                    <td><?php echo e($employee->email); ?></td>
                </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </tbody>
        </table>
    </div>
    </div>
    </div>

</body>
</html>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\john paul\Desktop\laravel-project\citihardwareSMS\resources\views/view-emp.blade.php ENDPATH**/ ?>