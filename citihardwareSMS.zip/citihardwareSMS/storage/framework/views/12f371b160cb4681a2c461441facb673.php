<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body style="background-color:#D8D9DA">


<br>
<br>
    <div class="container">
    <form class="row g-4" action="/edit-store/<?php echo e($store->id); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <h1 class="h3 mb-3 font-weight-normal">Edit Store Information</h1>
        <div class="col-md-6">  
            <label for="inputStoreName" class="form-label">Store Name</label>
            <input name="storeName" id="inputStoreName" class="form-control" type="text" value="<?php echo e($store->storeName); ?>">
        </div>
        <div class="col-md-6">
            <label for="inputAddress" class="form-label">Location</label>
            <input name="address" id="inputAddress" class="form-control" type="text" value="<?php echo e($store->address); ?>">
        </div>
        <div class="col-md-6">
            <label for="inputContact" class="form-label">Contact Number</label>
            <input name="phoneNumber" id="inputContact" class="form-control" type="number" value="<?php echo e($store->phoneNumber); ?>">
        </div>
        <div class="col-md-6">
            <label for="inputEmail" class="form-label">Email</label>
            <input name="email" id="inputEmail" class="form-control" type="email" value="<?php echo e($store->email); ?>">
        </div>
            <div class="col-12">
                <button class="btn btn-outline-primary">Save Changes</button>
            </div>
        </form>
    </div>
</body>
</html>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\john paul\Desktop\laravel-project\citihardwareSMS\resources\views//edit-store.blade.php ENDPATH**/ ?>