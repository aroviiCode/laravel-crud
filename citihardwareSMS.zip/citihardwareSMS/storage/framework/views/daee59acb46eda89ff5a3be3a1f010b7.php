<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body style="background-color:#D8D9DA">
    

    <div class="text-center mt-5">
       
        <form action="/register" method="POST" style="max-width:300px; margin:auto;"> 
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <h1 class="h3 mb-3 font-weight-normal">Please sign up</h1>
            <input name = "name" type = "text" id="username" class="form-control" placeholder="Username" required autofocus>

            <input name = "email" type = "email" id="email" class="form-control" placeholder="Email">
  
            <input name = "password" type = "password" id="password" class="form-control" placeholder="Password">
            <div  class="mt-3 d-grid">
                <button class="btn btn-lg btn-primary">Sign Up</button>
            </div>
        </form>
    </div>

</body>
</html>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\john paul\Desktop\laravel-project\citihardwareSMS\resources\views//register.blade.php ENDPATH**/ ?>