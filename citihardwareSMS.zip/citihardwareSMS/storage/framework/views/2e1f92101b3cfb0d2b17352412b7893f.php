<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    
   
    <h1>Edit Employee Information</h1>
    <form action="/edit-emp/<?php echo e($employee->id); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <input name = "emp_name" type="text" value="<?php echo e($employee->emp_name); ?>">
        <select name="position" id="position" >
            <option selected disabled><?php echo e($employee->position); ?></option>
            <option value="cashier">Cashier</option>
            <option value="manager">Manager</option>
            <option value="salesperson">Salesperson</option>
          </select>
        <input name="phone_number" type="number" value="<?php echo e($employee->phone_number); ?>">
        <input name="email" type="email" value="<?php echo e($employee->email); ?>">
        <input name="address" type="text" value="<?php echo e($employee->address); ?>">
        
        <select name="assign_store" id="assign_store" >
            <option selected disabled><?php echo e($employee->assign_store); ?></option>
            <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($store->id); ?>"><?php echo e($store->storeName); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <button>Save Changes</button>
</body>
</html>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\john paul\Desktop\laravel-project\citihardwareSMS\resources\views//edit-emp.blade.php ENDPATH**/ ?>