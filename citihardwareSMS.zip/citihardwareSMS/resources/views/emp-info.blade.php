<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body style="background-color:#D8D9DA">
    @extends('layout')
    @auth
    <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <ul class="navbar-nav" style="">
            <li class="nav-item active "> <a href="/" class="nav-link " style="font-weight:bold; font-family: Courier New;">STORES</a></li>
            <li class="nav-item active "> <a href="/emp-info" class="nav-link active" style="font-weight:bold; font-family: Courier New">EMPLOYEES</a></li>
            </ul> 
            <form class="d-flex" action="/logout" method="POST">
            @csrf
            <button class="btn btn-outline-success" style="font-weight:bold; font-family: Courier New;"> logout </button>
        </form>
        </div>
        </nav>
    <br>
    <br>
    <br>
   
    <div class="container border border-0">
        <br>
        
        <form class="row g-4" action="/employee" method="POST">
        @csrf
        <h2 style="">Create New Employee</h2>
        <div class="col-md-6">  
            <label for="inputemp-name" class="form-label">Fullname</label>
                <input name = "emp_name" type="text" class="form-control" id="inputemp-name" required autofocus>
        </div>
        <div class="col-md-6">
            <label for="inputPosition" class="form-label">Position</label>
                <select name="position" id="inputPosition" class="form-select">
                    <option selected disabled>--- Select Position ---</option>
                    <option value="cashier">Cashier</option>
                    <option value="manager">Manager</option>
                    <option value="salesperson">Salesperson</option>
                </select>
        </div>
        <div class="col-md-6">  
            <label for="inputPhone" class="form-label">Contact Number</label>
                <input name="phone_number" type="number" class="form-control" id="inputPhone">
        </div>
        <div class="col-md-6">
            <label for="inputEmail" class="form-label">Email</label>
                <input name="email" type="email" class="form-control" id="inputEmail">
        </div>
        <div class="col-md-6">
            <label for="inputAddress" class="form-label">Address</label>
                <input name="address" type="text" class="form-control" id="inputAddress">
        </div>
        <div class="col-md-6">
            <label for="inputStore" class="form-label">Position</label>
                <select name="assign_store" id="inputStore" class="form-select">
                    <option selected disabled>--- Select Store --- </option>
                        @foreach ($store as $stores)
                            <option>{{$stores->storeName}}</option>
                        @endforeach
                </select>
        </div>
        <div class="col-12 d-md-flex justify-content-md-end">
            <button class="btn btn-outline-primary">Create</button>
        </div>
        </form>
    </div>

    <br/>
    <br/><h1 style="text-align: center">LIST OF EMPLOYEES</h1>
        <div class="table-responsive">
        <table class="table">
            <thead>
            <tr>
                    <th>Name</th>
                    <th>Position</th>
                    <th>Phone Number</th>
                    <th>Email</th>
                    <th>Address</th>
                    <th>Store Assigned</th>
                    <th>Actions</th>
            </tr>
            </thead>
       @foreach ($employee as $employees)         
            <tr>  
                <td>{{$employees['emp_name']}}</td>
                <td>{{$employees['position']}}</td>
                <td>{{$employees['phone_number']}}</td>
                <td>{{$employees['email']}}</td>
                <td>{{$employees['address']}}</td>
                <td>{{$employees['assign_store']}}</td>
            <td>
            <a href="/edit-emp/{{$employees->id}}"><button class="btn btn-info btn-sm"><i class="fa fa-eye" aria-hidden="true"></i>EDIT</button></a>
                <form action="/delete-emp/{{$employees->id}}" method="POST"  style="display:inline">
                    @csrf <!-- {{ csrf_field() }} -->
                    @method('DELETE')
                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this employee?')"><i class="fa fa-trash-o" aria-hidden="true"></i>Delete</button>
                </form> 
            </td>
            </tr>  
        @endforeach
        </tbody>
        </table>
        </div>
 
    @else
    <div style="border: 3px solid black;">
        <h1>REGISTER</h1>
        <form action="/register" method="POST"> 
            @csrf
            <input name = "name" type = "text"  placeholder="username">
            <input name = "email" type = "text" placeholder="email">
            <input name = "password" type = "password" placeholder="password">
            <button>Register</button>
        </form>
    </div>
    <div style="border: 3px solid black;">
        <h1>LOG IN</h1>
        <form action="/login" method="POST"> 
            @csrf
            <input name = "logname" type = "text"  placeholder="username">
            <input name = "logpassword" type = "password" placeholder="password">
            <button>Login</button>
        </form>
    </div>

    @endauth
</body>
</html>