<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body style="background-color:#D8D9DA">
    @extends('layout')
    <br>
        <br>
    <div class="container">
       <form class="row g-4" action="/edit-emp/{{$employee->id}}" method="POST">
        @csrf 
        @method('PUT')
        
            <h1 class="h3 mb-3 font-weight-normal">Edit Employee Information</h1>
            <div class="col-md-6">  
                <label for="inputemp-name" class="form-label">Fullname</label>    
                <input name = "emp_name" id="inputemp-name" class="form-control" type="text" value="{{$employee->emp_name}}">
            </div>
            <div class="col-md-6">
                <label for="inputPosition" class="form-label">Position</label>
                <select name="position" id="inputPosition" class="form-select">
                    <option value="cashier">Cashier</option>
                    <option value="manager">Manager</option>
                    <option value="salesperson">Salesperson</option>
                </select>
            </div>
            <div class="col-md-6">  
                <label for="inputPhone" class="form-label">Contact Number</label>
                <input name="phone_number" id="inputPhone" class="form-control" type="number" value="{{$employee->phone_number}}">
            </div>
            <div class="col-md-6">
                <label for="inputEmail" class="form-label">Email</label>
                <input name="email" id="inputEmail" class="form-control" type="email" value="{{$employee->email}}">
            </div>
            <div class="col-md-6">
                <label for="inputAddress" class="form-label">Address</label>
                <input name="address" id="inputAddress" class="form-control" type="text" value="{{$employee->address}}">
            </div>
            <div class="col-md-6">
                <label for="inputStore" class="form-label">Position</label>
                    <select name="assign_store" id="inputStore" class="form-select">
                        <option selected disabled>{{$employee->assign_store}}</option>
                        @foreach ($stores as $store)
                            <option value="{{ $store->storeName }}">{{ $store->storeName }}</option>
                        @endforeach
                    </select>
            </div>
            <div class="col-12 d-md-flex justify-content-md-end">
                <button class="btn btn-outline-primary">Save Changes</button>
            </div>
        </form>
    </div>
</body>
</html>