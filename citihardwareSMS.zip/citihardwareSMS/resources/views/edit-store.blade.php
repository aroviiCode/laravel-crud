<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body style="background-color:#D8D9DA">
@extends ('layout')

<br>
<br>
    <div class="container">
    <form class="row g-4" action="/edit-store/{{$store->id}}" method="POST">
        @csrf
        @method('PUT')
        <h1 class="h3 mb-3 font-weight-normal">Edit Store Information</h1>
        <div class="col-md-6">  
            <label for="inputStoreName" class="form-label">Store Name</label>
            <input name="storeName" id="inputStoreName" class="form-control" type="text" value="{{$store->storeName}}">
        </div>
        <div class="col-md-6">
            <label for="inputAddress" class="form-label">Location</label>
            <input name="address" id="inputAddress" class="form-control" type="text" value="{{$store->address}}">
        </div>
        <div class="col-md-6">
            <label for="inputContact" class="form-label">Contact Number</label>
            <input name="phoneNumber" id="inputContact" class="form-control" type="number" value="{{$store->phoneNumber}}">
        </div>
        <div class="col-md-6">
            <label for="inputEmail" class="form-label">Email</label>
            <input name="email" id="inputEmail" class="form-control" type="email" value="{{$store->email}}">
        </div>
            <div class="col-12 d-md-flex justify-content-md-end">
                <button class="btn btn-outline-primary">Save Changes</button>
            </div>
        </form>
    </div>
</body>
</html>