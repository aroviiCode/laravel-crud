<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body style="background-color:#D8D9DA">
    @extends('layout')

    <div class="container">
        @php 
        $employeeCount = count($employees); // Get the total number of employees
        @endphp
        <div>
            <h1 class="h3 mb-3 font-weight-normal">Associated Employees</h1>
        </div>
        
        <p>Total Employees: {{ $employeeCount }}</p>
        <div class="row">
            <div class="col-md-12">
                <table class="table table-responsive">
                <thead class="table-dark">
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Email</th>

                </tr>
                </thead>
                <tbody>
                @foreach ($employees as $employee)
                <tr>
                    <th scope="row">{{$employee->id}}</th>
                    <td>{{$employee->emp_name}}</td>
                    <td>{{$employee->email}}</td>
                </tr>

                @endforeach 
            </tbody>
        </table>
    </div>
    </div>
    </div>

</body>
</html>