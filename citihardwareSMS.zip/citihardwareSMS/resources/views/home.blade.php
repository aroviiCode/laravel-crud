<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Homepage
    </title>
    <style>

    </style>

</head>
<body style="background-color:#D8D9DA">
@extends('layout')
    @auth
    
    <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <ul class="navbar-nav" style="">
        <li class="nav-item active "> <a href="/" class="nav-link active" style="font-weight:bold; font-family: Courier New;">STORES</a></li>
        <br>
        <li class="nav-item active "> <a href="/emp-info" class="nav-link" style="font-weight:bold; font-family:Courier New">EMPLOYEES</a></li>
        </ul> 
        <form class="d-flex" action="/logout" method="POST">
        @csrf
        <button class="btn btn-outline-success" style="font-weight:bold; font-family: Courier New;"> logout </button>
    </form>
    </div>
    </nav>
    
   <br>
   <br>
   <br>

    <div class="container border border-0">

        <br>
        <form class="row g-4" action="/store" method="POST">
        @csrf
        <h2 style="">Create New Store</h2>
        <div class="col-md-6">  
        <label for="inputStoreName" class="form-label">Store Name</label>
        <input  class="form-control" name = "storeName" type="text" id="inputStoreName" required autofocus>
        </div>
        <div class="col-md-6">
            <label for="inputAddress" class="form-label">Location</label>
            <input  class="form-control" name = "address" type="text" id="inputAddress">
        </div>
        <div class="col-md-6">
            <label for="inputContact" class="form-label">Contact Number</label>
            <input  class="form-control" name = "phoneNumber" type="number" id="inputContact">
        </div>
        <div class="col-md-6">
            <label for="inputEmail" class="form-label">Email</label>
            <input  class="form-control" name = "email" type="email" id="inputEmail">
            </div>
        <div class="col-12 d-md-flex justify-content-md-end" >
        <button class="btn btn-outline-primary">Create</button>
        </div>
        </form>
    </div>
    
    <br/><h1 style="text-align: center">LIST OF STORES</h1>
        <div class="table-responsive">
        <table class="table">
            <thead>
            <tr>
                    <th>Name</th>
                    <th>Location</th>
                    <th>Contact</th>
                    <th>Email</th>
            </tr>
            </thead>
       @foreach ($stores as $store)         
            <tr>  
                <td>{{$store['storeName']}}</td>
                <td>{{$store['address']}}</td>
                <td>{{$store['phoneNumber']}}</td>
                <td>{{$store['email']}}</td>
            <td>
                <a href="/view-emp/{{$store->id}}" title="View Employee"><button class="btn btn-info btn-sm"><i class="fa fa-eye" aria-hidden="true" style="font-weight:bold;"></i>VIEW</button></a>
            <a href="/edit-store/{{$store->id}}"><button class="btn btn-primary btn-sm"><i class="fa fa-eye" aria-hidden="true"></i>EDIT</button></a>
                <form action="/delete-store/{{$store->id}}" method="POST" style="display:inline">
                    @csrf <!-- {{ csrf_field() }} -->
                    @method('DELETE')
                    <button type="submit" onclick="return confirm('Are you sure you want to delete this store?')" class="btn btn-danger btn-sm"><i class="fa fa-trash-o" aria-hidden="true"></i>Delete</button>
                </form> 
            </td>
            </tr>  
        @endforeach
                </tbody>
            </table>
        </div>

    @else
   

    <div class="text-center mt-5" style="background-color:#D8D9DA">
        
        <form action="/login" method="POST" style="max-width:300px; margin:auto;"> 
            @csrf
            <h1 class="h3 mb-3 font-weight-normal">Please sign in</h1>
            <input name = "logname" type = "text" id="username" class="form-control" placeholder="Username" required autofocus>
            <input name = "logpassword" type = "password" id="password" class="form-control" placeholder="Password">
            <div  class="mt-3 d-grid">
            <button class="btn btn-lg btn-primary">Sign In</button>
            <a href="/register" style="text-decoration: none">Don't have an account?</a>
            </div>
           
            
        </form>
    </div>

    @endauth
    
    
</body>
</html>