<?php

namespace App\Models;

use App\Models\User;
use App\Models\Store;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\Employee as Authenticatable;

class Employee extends Model
{
    use  HasFactory, Notifiable;

    protected $primaryKey = 'id';
    protected $fillable = [
        'emp_name',
        'position',
        'phone_number',
        'email',
        'address',
        'assign_store',
        'user_id',
        'store_id'
    ];

    public function createnewEmployee(){

        return $this->hasMany(Store::class,'user_id');
    }

    public function storesS()
    {
        return $this->belongsTo(Store::class);
    }

    public function stores(){
        return $this->hasMany(Store::class);
   }

    public function inputBy(){
        return $this->belongsTo(User::class,'user_id');
    }



    //
    //
    public function store()
    {
        return $this->belongsTo(Store::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
