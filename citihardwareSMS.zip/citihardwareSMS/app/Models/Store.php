<?php

namespace App\Models;

use App\Models\User;
use App\Models\Employee;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Store extends Model
{
    use HasFactory, Notifiable;


    //protected $table = 'stores';
    protected $primaryKey = 'id';
    protected $fillable = [
        'storeName',
        'address',
        'phoneNumber',
        'email',
        'user_id'
    ];

    public function inputBy(){
        return $this->belongsTo(User::class,'user_id');
    }

    public function employee(){
        return $this->belongsTo(Employee::class);
    }

    //I have a users, stores, and employees tables. If I add a data inside my employees, I want the id of a specific stores and user to be included there.
    //
    public function employees()
    {
        return $this->hasMany(Employee::class);
    }

}
