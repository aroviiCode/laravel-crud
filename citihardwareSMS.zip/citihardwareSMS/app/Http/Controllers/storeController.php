<?php

namespace App\Http\Controllers;

use App\Models\Store;
use App\Models\Employee;
use Illuminate\Http\Request;

class storeController extends Controller
{

    public function deleteStore(Store $store){
        if(auth()->user()->id === $store['user_id']){
           $store->delete(); 
        }
        return redirect('/');

    }
    public function editStore(Store $store){
        if(auth()->user()->id !== $store['user_id']){
            return "You don't have the access to edit this data.";//redirect('');
        }
        return view('/edit-store',['store'=>$store]);
    }

    public function updateStore (Store $store, Request $request){
        if(auth()->user()->id !== $store['user_id']){
            return redirect('/');
        }

        $incomingField=$request->validate([
            'storeName'=>['required'],
            'address'=>['required','min:5'],
            'phoneNumber'=>['required','numeric','min:11'],
            'email'=>['required', 'email']
        ]);

        $incomingField['storeName']=strip_tags($incomingField['storeName']);
        $incomingField['address']=strip_tags($incomingField['address']);
        $incomingField['phoneNumber']=strip_tags($incomingField['phoneNumber']);
        $incomingField['email']=strip_tags($incomingField['email']);
        $store->update($incomingField);//Update Data
        return redirect('/');
    }


    public function createStore(Request $request) {

       $incomingField = $request->validate([
        'storeName'=>['required'],
        'address'=>['required','min:5'],
        'phoneNumber'=>['required','numeric','min:11'],
        'email'=>['required', 'email']
       ]);
        $incomingField['storeName']=strip_tags($incomingField['storeName']);
        $incomingField['address']=strip_tags($incomingField['address']);
        $incomingField['phoneNumber']=strip_tags($incomingField['phoneNumber']);
        $incomingField['email']=strip_tags($incomingField['email']);
        $incomingField['user_id']=auth()->id();
       Store::create($incomingField); //Create new data
       return redirect('/');
    }

public function showEmployees(Store $store)
{
    $employees = $store->employees;
    return view('view-emp', compact('employees', 'store'));
}
    
}