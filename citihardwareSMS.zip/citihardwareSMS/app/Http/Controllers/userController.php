<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class userController extends Controller
{

    public function logout (){
        auth()->logout();
        return redirect('/');
    }
    public function register(Request $request){
        $incomingField = $request->validate([
        'name' => ['required', 'min:5', Rule::unique('users', 'name')],
        'email' => ['required', 'email', Rule::unique('users', 'email')],
        'password' => ['required', 'min:8', 'max:20' ]
    ]);
        $incomingField ['password'] = bcrypt ($incomingField['password']);
        $user = User::create($incomingField);
        auth()->login($user); 
        return redirect('/');
    }

   public function login(Request $request) {
    $incomingField = $request->validate([
        'logname' => ['required'],
        'logpassword' => ['required']
    ]);

    if (auth()->attempt(['name' =>$incomingField['logname'], 'password' => $incomingField['logpassword']])){
     $request->session()->regenerate();
    }
    return redirect('/');
   }

   public function registerPage()
   {
    return view('/register');
   }
}
