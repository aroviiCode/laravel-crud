<?php

namespace App\Http\Controllers;

use App\Models\Store;
use App\Models\Employee;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class empController extends Controller
{   
    public function updateEmployee(Employee $employee, Request $request)
    {
        if (auth()->user()->id !== $employee->user_id) {
            return redirect('/emp-info');
        }
    
        $incomingField = $request->validate([
            'emp_name' => ['required', 'min:3'],
            'position' => [],
            'phone_number' => ['required', 'numeric', 'min:11'],
            'email' => ['required', 'email'],
            'address' => ['required'],
            'assign_store' => ['required']
        ]);
    
        $incomingField['emp_name'] = strip_tags($incomingField['emp_name']);
        $incomingField['phone_number'] = strip_tags($incomingField['phone_number']);
        $incomingField['email'] = strip_tags($incomingField['email']);
        $incomingField['address'] = strip_tags($incomingField['address']);
    
        // Find the store by its name
        $store = Store::where('storeName', $incomingField['assign_store'])->first();
    
        if ($store) {
            $incomingField['store_id'] = $store->id;
        } else {
            // Handle the case when the store is not found
            return redirect('/emp-info')->with('error', 'Assigned store not found.');
        }
    
        $employee->update($incomingField); // Update Data
        return redirect('/emp-info');
    }

    public function createEmployee(Store $store, Request $request)
{
    $incomingField = $request->validate([
        'emp_name' => ['required', 'min:3'],
        'position' => ['required'],
        'phone_number' => ['required', 'numeric', 'min:11'],
        'email' => ['required', 'email'],
        'address' => ['required'],
        'assign_store' => ['required']
    ]);

    $incomingField['emp_name'] = strip_tags($incomingField['emp_name']);
    $incomingField['position'] = strip_tags($incomingField['position']);
    $incomingField['phone_number'] = strip_tags($incomingField['phone_number']);
    $incomingField['email'] = strip_tags($incomingField['email']);
    $incomingField['address'] = strip_tags($incomingField['address']);

    // Find the store by its name
    $assignedStore = Store::where('storeName', $incomingField['assign_store'])->first();

    if ($assignedStore) {
        $incomingField['store_id'] = $assignedStore->id;
    } else {
        // Handle the case when the store is not found
        return redirect('/emp-info')->with('error', 'Assigned store not found.');
    }

    $incomingField['user_id'] = auth()->id();

    Employee::create($incomingField);

    return redirect('/emp-info')->with('Success', 'New employee successfully added!');
}
     

    public function employeeNav()
{
       $store=Store::all();
       $employee=Employee::all();
        return view('/emp-info', compact ('store', 'employee'));

}


    public function editEmp(Employee $employee){
        if(auth()->user()->id !== $employee['user_id']){
            return "You don't have the access to edit this data.";//redirect('');
        }
        return view('/edit-emp',['employee'=>$employee]);
        
    }

    public function deleteEmp(Employee $employee){
        if(auth()->user()->id === $employee['user_id']){
           $employee->delete(); 
        }
        return redirect('/emp-info');

    }

    public function populate(Employee $employee)
{
    $stores = Store::all(); // Fetch all stores
    return view('edit-emp', compact('stores', 'employee'));
}

}
