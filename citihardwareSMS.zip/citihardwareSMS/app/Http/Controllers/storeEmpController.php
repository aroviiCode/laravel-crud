<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class storeEmpController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $store = Auth::stores ();
        //$employees = Employee::all();
        $employees = Employee::where('store_id', $user->id)->orderBy('id', 'desc')->get();
        return view ('view-emp', compact('store', 'employees'));
    }


    public function viewEmployee()
    {
        $employee = [];
        if (auth()->check())
        {
            $employee = auth()->user()->employees()->latest()->get();
        }
        return view('home', ['employees' =>$employee]);


    }

    public function viewEmployeeS()
    {
        $store = [];
        if (auth()->check())
        {
            $employee = auth()->user()->stores()->latest()->get();
        }
        return view('view-emp', ['stores' =>$store]);


    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
